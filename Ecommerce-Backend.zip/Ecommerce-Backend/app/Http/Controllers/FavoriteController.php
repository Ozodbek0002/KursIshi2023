<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;


class FavoriteController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }

    public function index()
    {
        return auth()->user()->favorites()->paginate(10);
    }


    public function store(Request $request): JsonResponse
    {

        $request->validate([
            'product_id' => 'required|exists:products,id'
        ]);

        auth()->user()->favorites()->attach($request->product_id);

        return response()->json([
            'success' => true,
        ]);

    }





    public function  destroy($favorite_id): JsonResponse
    {
        if (auth()->user()->hasFavorite($favorite_id)) {
            auth()->user()->favorites()->detach($favorite_id);
            return response()->json([
                'success' => true,
            ]);
        } else {
            return response()->json([
                'success' => false,
            ]);
        }

    }





}
