<?php

namespace App\Http\Controllers;

use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use Illuminate\Pagination\CursorPaginator;



class ProductController extends Controller
{

    public function index()
    {
        return ProductResource::collection(Product::cursorPaginate(25));
    }


    public function create()
    {
        //
    }


    public function store(StoreProductRequest $request)
    {
        //
    }


    public function show(Product $product)
    {
        return $product->load('stocks');
    }

    public function edit(Product $product)
    {
        //
    }


    public function update(UpdateProductRequest $request, Product $product)
    {
        //
    }


    public function destroy(Product $product)
    {
        //
    }
}
