<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Spatie\Translatable\HasTranslations;

class Product extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = [
        'name',
        'description',
        'category_id',
        'price',
        'image',
    ];

    public array $translatable = [ "name", "description" ];



    public function category() :belongsTo
    {
        return $this->belongsTo(Category::class);
    }


    public function stocks() :hasMany
    {
        return $this->hasMany(Stock::class);
    }


    public function users() :belongsToMany
    {
        return $this->belongsToMany(User::class);
    }



}
