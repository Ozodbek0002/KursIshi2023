<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{

    public function run(): void
    {
        $admin = User::create([
            'first_name' => 'Admin',
            'last_name' => 'Admin',
            'email' => 'admin@gmail.com',
            'phone' => '123456789',
            'password' => Hash::make('secret'),
        ]);

//        $admin->assignRole('admin');
        $admin->roles()->attach(1);

        $user = User::create([
            'first_name' => 'Ozodbek',
            'last_name' => 'Ozodov',
            'email' => 'ozodbek@gmail.com',
            'phone' => '223456789',
            'password' => Hash::make('ozodbek'),
        ]);

        $user->roles()->attach(2);

        User::factory()->count(10)->hasAttached([Role::find(2)])->create();

    }
}

