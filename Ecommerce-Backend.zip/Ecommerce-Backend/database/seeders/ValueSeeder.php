<?php

namespace Database\Seeders;

use App\Models\Value;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ValueSeeder extends Seeder
{



    public function run(): void
    {

        Value::create([
            'attribute_id' => 1,
            'name' => [
                'uz'=>'qizil',
                'ru'=>'красный',
            ],
        ]);


        Value::create([
            'attribute_id' => 1,
            'name' => [
                'uz'=>'qora',
                'ru'=>'черный',
            ],
        ]);

        Value::create([
            'attribute_id' => 1,
            'name' => [
                'uz'=>'oq',
                'ru'=>'белый',
            ],
        ]);




        Value::create([
            'attribute_id' => 2,
            'name' => [
                'uz'=>'s',
                'ru'=>'s',
            ],
        ]);

        Value::create([
            'attribute_id' => 2,
            'name' => [
                'uz'=>'m',
                'ru'=>'m',
            ],
        ]);

        Value::create([
            'attribute_id' => 2,
            'name' => [
                'uz'=>'l',
                'ru'=>'l',
            ],
        ]);





        Value::create([
            'attribute_id' => 3,
            'name' => [
                'uz'=>'MDF',
                'ru'=>'МДФ',
            ],
        ]);

        Value::create([
            'attribute_id' => 3,
            'name' => [
                'uz'=>'LDSP',
                'ru'=>'ЛДСП',
            ],
        ]);

    }
}
