<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => [
                'uz'=>fake()->sentence(3),
                'ru'=>'Удобный искатель и тому подобные неприятности.',
                ],

            'description' => [
                'uz'=>fake()->paragraph(5),
                'ru'=>'Потому что тело свободно от боли и страданий. За ошибкой последует мудрое право. Ни о более суровых вещах настоящего. И не часто эти удовольствия. То есть он либо по удовольствию, либо кем. Результат меньше того, что я открою здесь. Однако для архитектора это особенно важно.',
                ],

            'price' => $this->faker->numberBetween(100000, 10000000),
            'image' => $this->faker->imageUrl(),
            'category_id' => $this->faker->numberBetween(1, 4),

        ];
    }
}
